<?php 
$server_name = "localhost";
$user_name = "root";
$password = "";
$dbname = "team";

$conn = new mysqli($server_name, $user_name,$password,$dbname);

 ?>